function y=Current_fix(x)
% I_ho=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\自动识别数据处理\raw_and_fitted_data.xlsx', 2, 'A2:A22');
% I_scope=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\自动识别数据处理\raw_and_fitted_data.xlsx', 2, 'B2:B22');
% I_ho_sort=sort(I_ho);
% I_scope_sort=sort(I_scope);
% %% 拟合: '无标题拟合 1'。
% [xData, yData] = prepareCurveData( I_ho_sort, I_scope_sort );
% 
% % 设置 fittype 和选项。
% ft = fittype( 'poly1' );
% 
% % 对数据进行模型拟合。
% [fitresult, gof] = fit( xData, yData, ft );
% coe=coeffvalues(fitresult);
y=1.057*x+0.1536;