function []=draw_theory_ab(fs1,fs2,fs3,Td1,Td2,Td3,Vd1,Vd2,Vd3,ADD)
%add为输入到excel表格具体哪一行那一列的矩阵
Ts=1e-4;
Td=4e-6;
Vdc=150;
C=7.2e-9;
Ton=0.08e-6;
Toff=0.29e-6;
%% 鐢垫満鍙傛暟
PN=5200;
Speed=2000;
P=3;
fN=Speed/60*P;
IN=10.6;
VN=380/sqrt(3);
Rs=1.416;
Ld=0.01339;
Lq=0.02501;
fs=[fs1 fs2 fs3 fs1 fs2 fs3 fs1 fs2 fs3];
Td=[Td1 Td1 Td1 Td2 Td2 Td2 Td3 Td3 Td3]*1e-6;

%%
%拟合每组数据的a与b两个参数
Vd80_values_ab=zeros(2,9);
Vd100_values_ab=zeros(2,9);
Vd120_values_ab=zeros(2,9);
for i=1:9
    [a,b]=Get_theory_comp_data(1/fs(i),Td(i),Vd1,Rs,C,Ton,Toff,Ld,IN);
    Vd80_values_ab(1,i)=a;
    Vd80_values_ab(2,i)=b;
    [a,b]=Get_theory_comp_data(1/fs(i),Td(i),Vd2,Rs,C,Ton,Toff,Ld,IN);
    Vd100_values_ab(1,i)=a;
    Vd100_values_ab(2,i)=b;
    [a,b]=Get_theory_comp_data(1/fs(i),Td(i),Vd3,Rs,C,Ton,Toff,Ld,IN);
    Vd120_values_ab(1,i)=a;
    Vd120_values_ab(2,i)=b;

end
%%
%原始数据与拟合数据写入excel
Vd80_values_ab_write=[Vd80_values_ab(1:2,1:3);Vd80_values_ab(1:2,4:6);Vd80_values_ab(1:2,7:9)];
Vd100_values_ab_write=[Vd100_values_ab(1:2,1:3);Vd100_values_ab(1:2,4:6);Vd100_values_ab(1:2,7:9)];
Vd120_values_ab_write=[Vd120_values_ab(1:2,1:3);Vd120_values_ab(1:2,4:6);Vd120_values_ab(1:2,7:9)];
add1=ADD(1,1);
sheet1=ADD(2,1);
start1=ADD(3,1);
add2=ADD(1,2);
sheet2=ADD(2,2);
start2=ADD(3,2);
add3=ADD(1,3);
sheet3=ADD(2,3);
start3=ADD(3,3);

xlswrite(add1,Vd80_values_ab_write,sheet1,start1);
xlswrite(add2,Vd100_values_ab_write,sheet2,start2);
xlswrite(add3,Vd120_values_ab_write,sheet3,start3);