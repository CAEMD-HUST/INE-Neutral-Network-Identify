function deltaV=Cal_deltaV_final2(Ts,Td,Vdc,VSW,VD,Rs,ia,C,Ton,Toff)
%%
ua=ia*Rs;
ub=-0.5*ia*Rs;
e=0.5*(0.5*Vdc-ua)+0.5*(-0.5*Vdc-ub);
D=(ua+e)/Vdc+0.5;

if D>=1
    D=1;
elseif D<0
    D=0;
end


Tdeq=Td+Ton-Toff;
icc=2*C*Vdc/Tdeq;
if abs(ia)<icc
 Tdeq=Tdeq*abs(ia)/icc;
end

% k1=C*Vdc*Vdc/Ts;
% 
% k2=Tdeq*Tdeq*Vdc/4/C/Ts+Tdeq*Vdc/2/Ts/i;
% 
% k3=Tdeq*Vdc/Ts+2*Tdeq*VD/Ts+(Ts-2*Tdeq)*VSW/Ts+C*Vdc*Vdc/2/Ts/i;
% 
% k4=2*Tdeq*VD/Ts+(Ts-2*Tdeq)*VSW/Ts;


% if abs(ia)>icc
%     deltaV=-k1/abs(ia)+sign(ia)*k3;
% else
%     deltaV=k2*ia+k4;
% end
deltaV=sign(ia)*Tdeq/Ts*Vdc+2*Tdeq*VD/Ts+(Ts-2*Tdeq)*VSW/Ts;


