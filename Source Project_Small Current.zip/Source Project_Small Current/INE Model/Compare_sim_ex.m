data_sim=xlsread("F:\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL_小电流\神经网络-小电流\GAN_final\Sim_Data_plt.xlsx", "Sheet1");
data_ex=xlsread("F:\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL_小电流\神经网络-小电流\GAN_final\Sim_Data_plt.xlsx", "Sheet2");
data_tran=xlsread("F:\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL_小电流\神经网络-小电流\GAN_final\Sim_Data_plt.xlsx", "Sheet3");
for i=1:size(data_ex,1)


            a_real=data_ex(i,4);
            b_real=data_ex(i,5);
            a_sim=data_sim(i,4);
            b_sim=data_sim(i,5);
            a_tran=data_tran(i,4);
            b_tran=data_tran(i,5);
            plot_x = 0:0.1:10.6;

            ploty1=a_real*2/pi*atan(b_real*plot_x);
            ploty2=a_sim*2/pi*atan(b_sim*plot_x);
            ploty3=a_tran*2/pi*atan(b_tran*plot_x);

            plot(plot_x,ploty1,'r',plot_x,ploty2,'b',plot_x,ploty3,'g');
            label=strcat('Vdc=',num2str(data_sim(i,1)),'V fs=',num2str(data_sim(i,3)),'Hz Td=',num2str(data_sim(i,2)),'us');
            xlabel(label);
            ylabel('Compensation Voltage/V');
            title('Compensation Voltage from Sim and Ex');
            legend('Offline Identification','INE Model','Proposed method');
            test=1;
    

end

