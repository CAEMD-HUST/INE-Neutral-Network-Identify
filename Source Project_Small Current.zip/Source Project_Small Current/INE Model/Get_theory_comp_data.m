function [a,b]=Get_theory_comp_data(Ts,Td,Vdc,Rs,C,Ton,Toff,Ld,IN)


%%
%计算补偿值并且拟合
ia=0:IN/100:IN;
deltaV=zeros(size(ia,2),1);
for i=1:size(ia,2)
    Td_use=Td;
    VSW=VswVDfit(ia(i),1);
    VD=VswVDfit(ia(i),2);
    deltaV(i)=Cal_deltaV_final2(Ts,Td_use,Vdc,VSW,VD,Rs,ia(i),C,Ton,Toff);
end
%%
%拟合
% plot(ia,deltaV);
% a=0;
% b=0;
VDT_fit_now=deltaV;
[fitresult, gof] = createFit(ia, VDT_fit_now);
coe=coeffvalues(fitresult);
a=coe(1);
b=coe(2);




