C=6.3e-9;
Ton=0.08e-6;
Toff=0.29e-6;
PN=5200;
Speed=2000;
P=3;
fN=Speed/60*P;
IN=10.6;
VN=380/sqrt(3);
Rs=1.416;
Ld=0.01339;
Lq=0.02501;

Vdc=150:150:450;
Td=(1:1:6)*1e-6;
fs=5000:1000:15000;

for i=1:3
    for j=1:6
        for m=1:11
            data_sim(m+(j-1)*11+(i-1)*66,1)=Vdc(i);
            data_sim(m+(j-1)*11+(i-1)*66,2)=Td(j);
            data_sim(m+(j-1)*11+(i-1)*66,3)=fs(m);
            [a,b]=Get_theory_comp_data(1/fs(m),Td(j),Vdc(i),Rs,C,Ton,Toff,Ld,IN);
            data_sim(m+(j-1)*11+(i-1)*66,4)=a;
            data_sim(m+(j-1)*11+(i-1)*66,5)=b;
        end
    end
end
xlswrite('F:\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL_小电流\模型值_new\Sim_Data.xlsx',data_sim,'sheet1','A1');

