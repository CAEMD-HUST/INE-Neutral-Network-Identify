function y=Clear_NAN(x)
n=1;
for i=1:size(x,1)
    for j=1:size(x,2)
        if isnan(x(i,j))
            return;
        else
            y(i,n)=x(i,j);
            n=n+1;
        end
    end
end