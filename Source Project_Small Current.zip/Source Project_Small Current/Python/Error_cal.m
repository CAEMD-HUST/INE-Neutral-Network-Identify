clc;
clear all;
data_V80=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'B3:D8');
data_V100=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'G3:I8');
data_V120=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'L3:N8');
data_real=[data_V80 data_V100 data_V120];
%ab值分别拿出来
data_a_real=[];
data_b_real=[];
for i=1:3%母线电压
    for j=1:3%死区
        for m=1:3%开关频率
            data_a_real=[data_a_real data_real(2*j-1,m+i*3-3)];
            data_b_real=[data_b_real data_real(2*j,m+i*3-3)];
        end
    end
end

data_V80=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'B12:D17');
data_V100=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'G12:I17');
data_V120=xlsread('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx', 1, 'L12:N17');
data_sim=[data_V80 data_V100 data_V120];
%ab值分别拿出来
data_a_sim=[];
data_b_sim=[];
for i=1:3%母线电压
    for j=1:3%死区
        for m=1:3%开关频率
            data_a_sim=[data_a_sim data_sim(2*j-1,m+i*3-3)];
            data_b_sim=[data_b_sim data_sim(2*j,m+i*3-3)];
        end
    end
end
for i=1:size(data_a_real,2)
    error_a(i)=abs(data_a_real(i)-data_a_sim(i))/data_a_real(i);
    error_b(i)=abs(data_b_real(i)-data_b_sim(i))/data_b_real(i);
end
plot(1:size(data_a_real,2),error_a);
% plot(1:size(data_a_real,2),error_b);