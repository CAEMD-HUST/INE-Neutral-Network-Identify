 # This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


import tensorflow as tf
import os
import numpy as np
import pandas as pd
import openpyxl
from matplotlib import pyplot as plt
from tensorflow.keras.layers import Conv2D, BatchNormalization, Activation, MaxPooling2D, Dropout, Flatten, Dense
from tensorflow.keras import Model
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import matplotlib.pyplot as plt
import math
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
np.set_printoptions(threshold=np.inf)


def min_max_normalize(data):
    min_vals = np.min(data, axis=1)  # 按列计算最小值
    max_vals = np.max(data, axis=1)  # 按列计算最大值
    normalized_data = (data - min_vals) / (max_vals - min_vals)
    return normalized_data, min_vals, max_vals


def min_max_denormalize(normalized_data, min_vals, max_vals):
    denormalized_data = normalized_data * (max_vals - min_vals) + min_vals
    return denormalized_data


# 画图函数 一次画一个母线电压下的18个数据
def plt_trans(x_real, t_real, t_sim, t_trans):
    plt.close()
    x_real = x_real.tolist()
    t_real = t_real.tolist()
    t_sim = t_sim.tolist()
    t_trans = t_trans.tolist()
    plt.figure(figsize=(15, 20))
    for i in range(0, len(x_real)):
        plt.subplot(6, 3, i+1)
        x = [j/50 for j in range(0, 107*5)]
        real_y = np.zeros(len(x)).tolist()
        sim_y = np.zeros(len(x)).tolist()
        trans_y = np.zeros(len(x)).tolist()
        for m in range(0, len(x)):
            real_y[m] = 2 * t_real[i][0] / math.pi*math.atan(x[m]*t_real[i][1])
            sim_y[m] = 2 * t_sim[i][0] / math.pi * math.atan(x[m] * t_sim[i][1])
            trans_y[m] = 2 * t_trans[i][0] / math.pi * math.atan(x[m] * t_trans[i][1])

        plt.plot(x, real_y, linestyle='-', color='red', linewidth=0.5, label='Real')
        plt.plot(x, sim_y, linestyle='-', color='blue', linewidth=0.5, label='Sim')
        plt.plot(x, trans_y, linestyle='-', color='green', linewidth=0.5, label='Trans')
        plt.legend()
        temp1 = 'Vdc='
        temp2 = 'Td='
        temp3 = 'fs='
        temp4 = ' '
        plt_title = temp1 + str(x_real[i][0]) + temp4 + temp2 + str(x_real[i][1]) + temp3 + str(x_real[i][2])
        plt.title(plt_title)
        plt.subplots_adjust(hspace=1)
    plt.show()




def plt_fit(x_real, t_real, t_fit):
    plt.close()
    x_real = x_real.tolist()
    t_real = t_real.tolist()
    t_fit = t_fit.tolist()
    for i in range(0, len(x_real)):
        plt.subplot(6, 3, i+1)
        x = [j/100 for j in range(0, 107)]
        a=len(x_real)
        # b=t_real[i, 0].tolist()*math.pi*math.atan(x[1]*t_real[i, 1].tolist())
        # c=len(x)
        real_y = np.zeros(len(x)).tolist()
        fit_y = np.zeros(len(x)).tolist()
        for m in range(0, len(x)):
            real_y[m] = t_real[i][0]*math.pi*math.atan(x[m]*t_real[i][1])
            fit_y[m] = t_fit[i][0] * math.pi * math.atan(x[m] * t_fit[i][1])


        plt.plot(x, real_y, linestyle='-', color='red', linewidth=0.5, label='Real')
        plt.plot(x, fit_y, linestyle='-', color='blue', linewidth=0.5, label='fit')
        plt.legend()
        temp1 = 'Vdc='
        temp2 = 'Td='
        temp3 = 'fs='
        temp4 = ' '
        plt_title = temp1 + str(x_real[i][0]) + temp4 + temp2 + str(x_real[i][1]) + temp3 + str(x_real[i][2])
        plt.title(plt_title)
        plt.subplots_adjust(hspace=0.5)
    plt.figure(figsize=(19.2, 10.8))
    plt.show()

train_rate = 0.001
#从excel中导入数据
# 打开并读取Excel文件
wb = openpyxl.load_workbook('Sim_Data.xlsx')
sheet1 = wb['Sheet1']
sheet2 = wb['Sheet2']

# 提取需要的列作为输入
input_cols = [0, 1, 2, 3, 4]
Sim_data = []
temp1_data = []
for row in sheet1.iter_rows(min_row=1, values_only=True):
    Sim_data = [row[i] for i in input_cols]
    temp1_data.append(Sim_data)

Sim_data = np.array(temp1_data) #电压 死区 开关频率 a b
temp1_data = []
input_cols = [0, 1, 2, 3, 4]
Real_data = []
for row in sheet2.iter_rows(min_row=1, values_only=True):
    Real_data = [row[i] for i in input_cols]
    temp1_data.append(Real_data)

Real_data = np.array(temp1_data)
# 提取需要的列作为标签
label_cols = [4, 5]  # 第5、6

# 仿真与实验数据输入输出划分
X_sim=Sim_data[:, :3]
T_sim=Sim_data[:, 3:5]
X_real=Real_data[:, :3]
T_real=Real_data[:, 3:5]



X_sim = np.transpose(X_sim)
T_sim = np.transpose(T_sim)
X_real = np.transpose(X_real)
T_real = np.transpose(T_real)



# 创建StandardScaler对象
input_scaler = MinMaxScaler(feature_range=(1, 3))
label_scaler = MinMaxScaler(feature_range=(1, 3))

# 将数据进行标准化
normalize_temp = np.transpose(np.concatenate((X_sim, X_real), axis=1))
normalized_X = input_scaler.fit_transform(normalize_temp)
normalize_temp = np.transpose(np.concatenate((T_sim, T_real), axis=1))
normalized_T = label_scaler.fit_transform(normalize_temp)



normalized_X_sim=normalized_X[:X_sim.shape[1], :]
normalized_T_sim=normalized_T[:T_sim.shape[1], :]
normalized_X_real=normalized_X[X_sim.shape[1]:normalized_X.shape[0], :]
normalized_T_real=normalized_T[T_sim.shape[1]:normalized_T.shape[0], :]

# a = input_scaler.inverse_transform(normalized_X_sim)
# b = input_scaler.inverse_transform(normalized_X_real)
# c = label_scaler.inverse_transform(normalized_T_sim)
# d = label_scaler.inverse_transform(normalized_T_real)

normalized_X_real_sim = normalized_X_real
normalized_T_real_sim = normalized_T_real
real_sim_location_record = np.zeros(normalized_X_real.shape[0])
for i in range(0, normalized_X_real.shape[0]):
    for j in range(0, normalized_X_sim.shape[0]):
        if normalized_X_real[i,0]==normalized_X_sim[j,0] and normalized_X_real[i,1]==normalized_X_sim[j,1] and normalized_X_real[i,2]==normalized_X_sim[j,2]:
            normalized_X_real_sim[i,:] = normalized_X_sim[j,:]
            normalized_T_real_sim[i,:] = normalized_T_sim[j,:]
            real_sim_location_record[i] = j

# normalized_X_real_sim是与实际值normalized_X_real对应的仿真值
# normalized_T_real_sim是与实际值normalized_T_real对应的仿真值


# X = normalized_inputs[ :15, :]#第0-第3个共4个数
# T = normalized_labels[ :15, :]
# # print(X_train)
# # print(T_train)
# # X = np.expand_dims(X, axis=-1)
# # # X = np.expand_dims(X, axis=1)
# X_train, X_test, T_train, T_test = train_test_split(X, T, test_size=test_rate, random_state=42)
#
# # T_train = np.expand_dims(T_train, axis=2)
# # print(X_train)
# # inverse_normalized_labels = label_scaler.inverse_transform(normalized_labels)
# # inverse_normalized_inputs = input_scaler.inverse_transform(normalized_inputs)

# 设置随机数种子
seed = 56
tf.random.set_seed(seed)
np.random.seed(seed)
#

class Baseline(Model):
    def __init__(self, sim_x, sim_t, real_x, real_t, sim_Real_t, real_x_adjust, real_t_adjust,
                 real_x_nopretrain, real_t_nopretrain, sim_t_nopretrain, k_ab=0.7, k_sim=0.2):
        super(Baseline, self).__init__()
        # 开关频率、母线电压、死区时间共三个数据
        self.sim_x = sim_x
        self.sim_t = sim_t
        self.real_x = real_x
        self.real_t = real_t
        self.sim_Real_t = sim_Real_t
        self.real_x_adjust = real_x_adjust
        self.real_t_adjust = real_t_adjust
        self.real_X_nopretrain = real_x_nopretrain
        self.real_t_nopretrain = real_t_nopretrain
        self.sim_t_nopretrain = sim_t_nopretrain
        self.k_ab = k_ab
        self.k_sim = k_sim
        self.fc1 = Dense(3, activation='relu')
        self.fc2 = Dense(200, activation='relu', kernel_initializer='random_normal')
        self.fc3 = Dense(200, activation='relu', kernel_initializer='random_normal')
        # self.fc4 = Dense(45, activation='relu', kernel_initializer='random_normal')
        self.fc5 = Dense(2, activation='relu')
        # self.fc2 = Dense(2, activation='linear' 'relu', kernel_initializer='random_normal')

    def call(self, x):# 前向传播 输入数据是x
        x = self.fc1(x)
        x = self.fc2(x)
        # x = self.fc3(x)
        # x = self.fc4(x)
        y = self.fc5(x)
        return y

    def loss_pre_train_n1(self): # 先使用全部仿真数据训练神经网络，再用少量数据实际数据微调
        temp_sim = self.call(self.sim_x) # 前向传播得到神经网络的输出
        temp1 = self.sim_t - temp_sim # 仿真T-前向传播的T
        # ab之间占比
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1-self.k_ab)

        # 将两列相加得到新的一列
        new_col = col1 + col2
        loss = tf.reduce_mean(tf.square([col1, col2]), keepdims=True)
        return loss

    def loss_adjust_n1(self):# 使用实验数据微调神经网络
        temp_real = self.call(self.real_x_adjust) #前向传播得到仿真训练好的网络n1对于实际输入的输出值
        temp1 = self.real_t_adjust - temp_real
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1-self.k_ab)
        # new_col = col1 + col2
        # loss = tf.reduce_mean(tf.square(new_col), keepdims=True)
        loss = tf.reduce_mean(tf.square([col1, col2]), keepdims=True)
        return loss

    def loss_adjust_n1_method2(self):# 使用实验数据微调神经网络
        # 计算与实际值的偏差
        temp_real = self.call(self.real_x_adjust) #前向传播得到仿真训练好的网络n1对于实际输入的输出值
        temp1 = self.real_t_adjust - temp_real
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1-self.k_ab)
        # 计算与仿真值的偏差
        temp_sim = self.call(self.sim_x)
        temp2 = self.sim_t - temp_sim
        col2 = temp1[:, 0] * self.k_ab
        col3 = temp1[:, 1] * (1 - self.k_ab)
        loss = tf.reduce_mean(tf.square([col1, col2]), keepdims=True)
        return loss

    def loss_no_pre_train(self):# 直接使用少量的实验数据进行训练，但是损失函数中包含仿真数据有关的项
        #计算与实际值的偏差
        temp_real = self.call(self.real_x_nopretrain)
        temp1 = self.real_t_nopretrain - temp_real
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1-self.k_ab)
        new_col = col1 + col2
        loss_real = tf.reduce_mean(tf.square(new_col), keepdims=True)
        #计算与仿真值的偏差
        temp_sim = self.call(self.real_x_nopretrain)
        temp1 = self.sim_t_nopretrain - temp_sim
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1 - self.k_ab)
        new_col = col1 + col2
        loss_sim = tf.reduce_mean(tf.square([col1, col2]), keepdims=True)

        loss = loss_sim*self.k_sim + loss_real*(1-self.k_sim)
        return loss

    def loss_Train_n1_only_2ex_data(self):
        temp_real = self.call(self.real_x_adjust)
        temp1 = self.real_t_adjust - temp_real
        col1 = temp1[:, 0] * self.k_ab
        col2 = temp1[:, 1] * (1 - self.k_ab)
        new_col = col1 + col2
        # 计算与仿真值的偏差
        loss = tf.reduce_mean(tf.square([col1, col2]), keepdims=True)
        return loss


    def Pre_train_n1(self, epoch=5, loss_choose=None, rate=train_rate, loss_coe=1): #先使用全部仿真数据训练神经网络，再用少量数据实际数据微调
        self.optimizer = tf.optimizers.Adam(rate)

        for _ in range(0, epoch):
            with tf.GradientTape() as g:
                loss = loss_coe * self.loss_pre_train_n1()

            gradients = g.gradient(loss, self.trainable_variables) #可训练变量是在创建层的时候自动定义的，直接调用即可
            # 更新W，b
            self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))
            print("Pre_train_n1, step: %i/%i, loss: %f" % (_, epoch, loss))

            if loss < 0.0000001:
                break

    def Train_n1_only_2ex_data(self, epoch=1000, rate=train_rate):
        self.optimizer = tf.optimizers.Adam(rate)

        for _ in range(0, epoch):
            with tf.GradientTape() as g:
                loss = self.loss_Train_n1_only_2ex_data()

            gradients = g.gradient(loss, self.trainable_variables) #可训练变量是在创建层的时候自动定义的，直接调用即可
            # 更新W，b
            self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))
            print("Train_n1_only_2ex_data, step: %i/%i, loss: %f" % (_, epoch, loss))

            if loss < 0.0000001:
                break

    def Adjust_n1(self, epoch, method=1, rate=train_rate, loss_coe=1): #先使用全部仿真数据训练神经网络，再用少量数据实际数据微调
        self.optimizer = tf.optimizers.Adam(rate)

        for _ in range(0, epoch):
            with tf.GradientTape() as g:
                if method == 1:
                    loss = loss_coe * self.loss_adjust_n1()
                else:
                    loss = loss_coe * self.loss_adjust_n1_method2()

            gradients = g.gradient(loss, self.trainable_variables) #可训练变量是在创建层的时候自动定义的，直接调用即可
            # 更新W，b
            self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))
            print("Adjust_n1, step: %i/%i, loss: %f" % (_, epoch, loss))

            if loss < 0.0000001:
                break



    def No_pre_train(self, epoch=1, loss_choose=None, rate=train_rate): #先使用全部仿真数据训练神经网络，再用少量数据实际数据微调
        self.optimizer = tf.optimizers.Adam(rate)

        for _ in range(0, epoch):
            with tf.GradientTape() as g:
                loss = self.loss_no_pre_train()

            gradients = g.gradient(loss, self.trainable_variables) #可训练变量是在创建层的时候自动定义的，直接调用即可
            # 更新W，b
            self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))
            print("Pre_train_n1, step: %i/%i, loss: %f" % (_, epoch, loss))

            if loss < 0.0000001:
                break


# 先用300V的所有数据进行调整
# real_x_adjust = np.zeros((18, normalized_X_real.shape[1]))
# real_t_adjust = np.zeros((18, normalized_T_real.shape[1]))
# for i in range(18, 36):
#     real_x_adjust[i-18,:] = normalized_X_real[i, :]
#     real_t_adjust[i-18,:] = normalized_T_real[i, :]
# a = normalized_X_real[18, :].reshape(-1,1).transpose()

# real_x_adjust = np.concatenate((normalized_X_real[18, :].reshape(-1,1).transpose(), normalized_X_real[35, :].reshape(-1,1).transpose()), axis=0)
# real_t_adjust = np.concatenate((normalized_T_real[18, :].reshape(-1,1).transpose(), normalized_T_real[35, :].reshape(-1,1).transpose()), axis=0)
real_x_adjust = np.concatenate((normalized_X_real[1, :].reshape(-1,1).transpose(), normalized_X_real[17, :].reshape(-1,1).transpose()), axis=0)
real_t_adjust = np.concatenate((normalized_T_real[1, :].reshape(-1,1).transpose(), normalized_T_real[17, :].reshape(-1,1).transpose()), axis=0)


# 只用300V的实际数据和仿真数据训练
real_x_nopretrain = real_x_adjust
real_t_nopretrain = real_t_adjust
sim_t_nopretrain  = np.zeros((18, real_t_adjust.shape[1]))
for i in range(0, real_x_nopretrain.shape[0]):
    for j in range(0, normalized_X_sim.shape[0]):
        if real_x_nopretrain[i,0]==normalized_X_sim[j,0] and real_x_nopretrain[i,1]==normalized_X_sim[j,1] and real_x_nopretrain[i,2]==normalized_X_sim[j,2]:
            sim_t_nopretrain[i,:] = normalized_T_sim[j,:]


# 定义神经网络并训练，方式1：
model1 = Baseline(normalized_X_sim, normalized_T_sim, normalized_X_real, normalized_T_real, normalized_T_real_sim,
                   real_x_adjust, real_t_adjust, real_x_nopretrain,real_t_nopretrain, sim_t_nopretrain)

model1.Train_n1_only_2ex_data(epoch=1000)



# 微调 方式1：
model2 = model1

trans_T_nom = model2.call(normalized_X_real)
# 反归一化
trans_T_real = label_scaler.inverse_transform(trans_T_nom)
# 以下画图：
T_real_sim = label_scaler.inverse_transform(normalized_T_real_sim)
plt_trans(X_real[:, 0:17].transpose(), T_real[:, 0:17].transpose(), T_real_sim[0:17, :], trans_T_real[0:17, :])
test = 1
plt_trans(X_real[:, 18:35].transpose(), T_real[:, 18:35].transpose(), T_real_sim[18:35, :], trans_T_real[18:35, :])
test = 1
plt_trans(X_real[:, 36:53].transpose(), T_real[:, 36:53].transpose(), T_real_sim[36:53, :], trans_T_real[36:53, :])
test = 1

X_store = X_real.transpose()
T_real_store = T_real.transpose()
T_real_sim_store = T_real_sim
trans_T_real_store = trans_T_real

np.savetxt('X_store1.txt', X_store, fmt='%f')
np.savetxt('T_real_store1.txt', T_real_store, fmt='%f')
np.savetxt('T_real_sim_store1.txt', T_real_sim_store, fmt='%f')
np.savetxt('trans_T_real_store1.txt', trans_T_real_store, fmt='%f')
test = 1
# # 微调 方式2：
# model2 = model1
# for i in range(0, 100):
#      model2.Adjust_n1(epoch=1, method=2)
#
#      trans_T_nom = model2.call(normalized_X_real)
#      # 反归一化
#      trans_T_real = label_scaler.inverse_transform(trans_T_nom)
#      # 以下画图：
#      T_real_sim = label_scaler.inverse_transform(normalized_T_real_sim)
#      plt_trans(X_real[:, 0:17].transpose(), T_real[:, 0:17].transpose(), T_real_sim[0:17, :], trans_T_real[0:17, :])
#      test = 1
#      plt_trans(X_real[:, 18:35].transpose(), T_real[:, 18:35].transpose(), T_real_sim[18:35, :], trans_T_real[18:35, :])
#      test = 1
#      plt_trans(X_real[:, 36:53].transpose(), T_real[:, 36:53].transpose(), T_real_sim[36:53, :], trans_T_real[36:53, :])
#      test = 1
