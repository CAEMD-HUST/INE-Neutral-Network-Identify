clear all;
clc;
pre=0;
exp_sim_data=read_draw_data("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\raw_and_fitted_data.xlsx", "Sheet3", [1, 45]);
if pre==1
    real_prediction = load('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\Train\real_prediction.txt');
    I=load('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\Train\IN_IN_div.txt');
else
    real_prediction = load('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\train_dense\real_prediction.txt');
    I=load('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\train_dense\IN_IN_div.txt');
end

a_real=table2array(exp_sim_data(1:15,1));
b_real=table2array(exp_sim_data(1:15,2));
% a_fit=real_prediction(:,1);
% b_fit=real_prediction(:,2);
a_sim=table2array(exp_sim_data(1:15,3));
b_sim=table2array(exp_sim_data(1:15,4));
IN=10.6;
x=0:IN/200:2*IN;
for i=1:size(a_real)
    %先拟合
    voltagefit_temp=zeros(I(2,1),1);
    I_fit_temp=zeros(I(2,1),1);
    for j=1:I(2,1)
        voltagefit_temp(j)=real_prediction((i-1)*I(2,1)+j);
        I_fit_temp(j)=I(1,1)/I(2,1)*j;
    end
    [xData, yData] = prepareCurveData( I_fit_temp, voltagefit_temp );

    % 设置 fittype 和选项。
    ft = fittype( 'a*2/pi*atan(b*x)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.706046088019609 0.0318328463774207];

    % 对数据进行模型拟合。
    [fitresult, gof] = fit( xData, yData, ft, opts );
    coe=coeffvalues(fitresult);
    a_fit=coe(1);
    b_fit=coe(2);


    ploty1=a_real(i)*2/pi*atan(b_real(i)*x);
    ploty2=a_fit*2/pi*atan(b_fit*x);
    ploty3=a_sim(i)*2/pi*atan(b_sim(i)*x);
    plot(x,ploty1,'r',x,ploty2,'b',x,ploty3,'g');
    %     label=strcat('Vdc=',vd_str(i),' fs=',fs_str(j),' Td=',Td_str(m));
    xlabel('电流(A)');
    ylabel('补偿电压(V)');
    title('补偿电压对比');
    %             legend('实验补偿值');
    %             hold on;
    %             plot(plot_x,ploty2,'b');
    %             xlabel(['Vdc=' vd_str(i) ' fs=' fs_str(j) ' Td=' Td_str(m)]);
    %             ylabel('补偿电压(V)');
    %             title('仿真与实验补偿电压对比');
    legend('实验补偿值','神经网络第一步拟合补偿值','仿真补偿值');
    test=1;
end

close all;
%迁移学习画图 
real_prediction_trans = load('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\Error Cal and Learning\train_dense\real_prediction_trans.txt');

a_real=table2array(exp_sim_data(16:30,1));
b_real=table2array(exp_sim_data(16:30,2));
% a_fit=real_prediction(:,1);
% b_fit=real_prediction(:,2);
a_sim=table2array(exp_sim_data(16:30,3));
b_sim=table2array(exp_sim_data(16:30,4));
IN=10.6;
x=0:IN/200:IN;
for i=1:size(a_real)
    %先拟合
    voltagefit_temp=zeros(I(2,1),1);
    I_fit_temp=zeros(I(2,1),1);
    for j=1:I(2,1)
        voltagefit_temp(j)=real_prediction((i-1)*I(2,1)+j);
        I_fit_temp(j)=I(1,1)/I(2,1)*j;
    end
    [xData, yData] = prepareCurveData( I_fit_temp, voltagefit_temp );

    % 设置 fittype 和选项。
    ft = fittype( 'a*2/pi*atan(b*x)', 'independent', 'x', 'dependent', 'y' );
    opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
    opts.Display = 'Off';
    opts.StartPoint = [0.706046088019609 0.0318328463774207];

    % 对数据进行模型拟合。
    [fitresult, gof] = fit( xData, yData, ft, opts );
    coe=coeffvalues(fitresult);
    a_fit=coe(1);
    b_fit=coe(2);


    ploty1=a_real(i)*2/pi*atan(b_real(i)*x);
    ploty2=a_fit*2/pi*atan(b_fit*x);
    ploty3=a_sim(i)*2/pi*atan(b_sim(i)*x);
    plot(x,ploty1,'r',x,ploty2,'b',x,ploty3,'g');
    %     label=strcat('Vdc=',vd_str(i),' fs=',fs_str(j),' Td=',Td_str(m));
    xlabel('电流(A)');
    ylabel('补偿电压(V)');
    title('补偿电压对比');
    %             legend('实验补偿值');
    %             hold on;
    %             plot(plot_x,ploty2,'b');
    %             xlabel(['Vdc=' vd_str(i) ' fs=' fs_str(j) ' Td=' Td_str(m)]);
    %             ylabel('补偿电压(V)');
    %             title('仿真与实验补偿电压对比');
    legend('实验补偿值','神经网络迁移学习补偿值','仿真补偿值');
    test=1;
end