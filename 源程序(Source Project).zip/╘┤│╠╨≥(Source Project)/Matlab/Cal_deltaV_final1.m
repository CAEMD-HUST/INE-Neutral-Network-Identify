function deltaV=Cal_deltaV_final1(Ts,Td,Vdc,VSW,VD,Rs,ia,C,Ton,Toff)
%%
ua=ia*Rs;
ub=-0.5*ia*Rs;
e=0.5*(0.5*Vdc-ua)+0.5*(-0.5*Vdc-ub);
D=(ua+e)/Vdc+0.5;

if D>=1
    D=1;
elseif D<0
    D=0;
end

%鍏呮斁鐢垫椂鐨勫啿閲?
Vt1=0;
Vt2=0;
Vt3=0;
Vt4=0;
%
Tcd=C/abs(ia)*(Vdc+VD-VSW);
if ia>=0
    Vup=0.5*Vdc-VSW;
    Vlow=-0.5*Vdc-VD;
else
    Vup=0.5*Vdc+VD;
    Vlow=-0.5*Vdc+VSW;
end

if ia>=0
    %VT1
    Tonoff=Ton;
    if Tonoff*abs(ia)/C>=Vup-Vlow
        temp1=2*Tonoff-Tcd+C/abs(ia)*Vlow;
        temp2=C/abs(ia)*Vlow*Vlow;
        Vt1=0.5*temp1*Vup-0.5*temp2;
    elseif Tonoff*abs(ia)/C<=-Vlow
        temp3=2*Vlow+abs(ia)/C*Tonoff;
        Vt1=0.5*temp3*Tonoff;
    else
        temp4=Tonoff+Vlow*C/abs(ia);
        temp5=abs(ia)/C*Tonoff+Vlow;
        temp6=C/abs(ia)*Vlow*Vlow;
        Vt1=0.5*temp4*temp5-0.5*temp6;
    end
    %Vt2
    Tonoff=Toff;
    if Tonoff*abs(ia)/C>=Vup-Vlow
        temp1=2*Tonoff-Tcd-C/abs(ia)*Vup;
        temp2=C/abs(ia)*Vup*Vup;
        Vt2=0.5*temp1*Vlow+0.5*temp2;
    elseif Tonoff*abs(ia)/C<=Vup
        temp3=2*Vup-abs(ia)/C*Tonoff;
        Vt2=0.5*temp3*Tonoff;
    else
        temp4=Tonoff-Vup*C/abs(ia);
        temp5=abs(ia)/C*Tonoff-Vup;
        temp6=C/abs(ia)*Vup*Vup;
        Vt2=-0.5*temp4*temp5+0.5*temp6;
    end
end

if ia<=0
    %VT3
    Tonoff=Toff;
    if Tonoff*abs(ia)/C>=Vup-Vlow
        temp1=2*Tonoff-Tcd+C/abs(ia)*Vlow;
        temp2=C/abs(ia)*Vlow*Vlow;
        Vt3=0.5*temp1*Vup-0.5*temp2;
    elseif Tonoff*abs(ia)/C<=-Vlow
        temp3=2*Vlow+abs(ia)/C*Tonoff;
        Vt3=0.5*temp3*Tonoff;
    else
        temp4=Tonoff+Vlow*C/abs(ia);
        temp5=abs(ia)/C*Tonoff+Vlow;
        temp6=C/abs(ia)*Vlow*Vlow;
        Vt3=0.5*temp4*temp5-0.5*temp6;
    end
    %Vt4
    Tonoff=Ton;
    if Tonoff*abs(ia)/C>=Vup-Vlow
        temp1=2*Tonoff-Tcd-C/abs(ia)*Vup;
        temp2=C/abs(ia)*Vup*Vup;
        Vt4=0.5*temp1*Vlow+0.5*temp2;
    elseif Tonoff*abs(ia)/C<=Vup
        temp3=2*Vup-abs(ia)/C*Tonoff;
        Vt4=0.5*temp3*Tonoff;
    else
        temp4=Tonoff-Vup*C/abs(ia);
        temp5=abs(ia)/C*Tonoff-Vup;
        temp6=C/abs(ia)*Vup*Vup;
        Vt4=-0.5*temp4*temp5+0.5*temp6;
    end
end

temp1=0.5*Vdc-VSW;
temp2=0.5*Vdc+VD;
temp3=D*Ts-Td-Ton;
temp4=(1-D)*Ts+Td-Toff;
temp5=D*Ts+Td-Toff;
temp6=(1-D)*Ts-Td-Ton;
if ia>=0
    VT_real=temp1*temp3-temp2*temp4+Vt1+Vt2;
    deltaV=0.5*Vdc*(2*D-1)-VT_real/Ts;
else
    VT_real=temp2*temp5-temp1*temp6+Vt3+Vt4;
    deltaV=0.5*Vdc*(2*D-1)-VT_real/Ts;
end