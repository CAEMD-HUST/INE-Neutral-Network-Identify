%%
%读入数据并预处理得到死区补偿数据 fs=10000 5000 15000，DT=1us 3us 5us
clear all;
clc;
%%
C=6.2e-9;
Ton=0.1e-6;
Toff=0.36e-6;
PN=5200;
Speed=2000;
P=3;
fN=Speed/60*P;
IN=10.6;
VN=380/sqrt(3);
Rs=1.416;
Ld=0.01339;
Lq=0.02501;
EMF=306/sqrt(3);
coe_a=[];
coe_b=[];
coe_Vdc=[];
coe_Td=[];
coe_fs=[];

Vdc=150:50:450;
Td=1:1:6;
Td=Td*1e-6;
fs=5000:1000:15000;
for a=1:size(Vdc,2)
    for b=1:size(Td,2)
        for c=1:size(fs,2)
            [a_temp,b_temp] = Get_theory_comp_data(1/fs(c),Td(b),Vdc(a),Rs,C,Ton,Toff,Ld,IN);
            coe_a=[coe_a a_temp];
            coe_b=[coe_b b_temp];
            coe_Vdc=[coe_Vdc Vdc(a)];
            coe_Td=[coe_Td Td(b)];
            coe_fs=[coe_fs fs(c)];
            disp(c+(b-1)*size(fs,2)+(a-1)*size(Td,2)*size(fs,2));
        end
    end
end

test=1;
write_temp1=[coe_Vdc;coe_Td;coe_fs;coe_a;coe_b]';
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\Sim_Data.xlsx',write_temp1,'sheet1','A1');
%%
% Vdc=150:50:450;
% Td=1:1:6;
% Td=Td*1e-6;
% fs=5000:1000:15000;
% for a=1:size(Vdc,2)
%     for b=1:size(Td,2)
%         for c=1:size(fs,2)
%             [a_temp,b_temp] = Get_theory_comp_data(1/fs(c),Td(b),Vdc(a),Rs,C,Ton,Toff,Ld,IN);
%             coe_a=[coe_a a_temp];
%             coe_b=[coe_b b_temp];
%             coe_Vdc=[coe_Vdc Vdc(a)];
%             coe_Td=[coe_Td Td(b)];
%             coe_fs=[coe_fs fs(c)];
%             disp(c+(b-1)*size(fs,2)+(a-1)*size(Td,2)*size(fs,2));
%         end
%     end
% end
% 
% test=1;
% write_temp2=[coe_Vdc;coe_Td;coe_fs;coe_a;coe_b]';
% xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\Sim_Data.xlsx',write_temp2,'sheet1','A1');
%%
%实验数据处理
% 处理135us
adjust_coe=0.5;
Vd150_vds_135=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=150.dat");
Vd300_vds_135=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=300.dat");
Vd450_vds_135=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=450.dat");
Vd150_vds_246=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=150.dat");
Vd300_vds_246=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=300.dat");
Vd450_vds_246=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=450.dat");
Vd150_VDT_135=zeros(90,1);
Vd300_VDT_135=zeros(90,1);
Vd450_VDT_135=zeros(90,1);
Vd150_VDT_246=zeros(90,1);
Vd300_VDT_246=zeros(90,1);
Vd450_VDT_246=zeros(90,1);

for i=1:9
    for j=1:10
        Vd150_VDT_135(j+10*(i-1))=1.5*(Vd150_vds_135(j+20*(i-1))-Vd150_vds_135(j+20*(i-1)+10));
        Vd300_VDT_135(j+10*(i-1))=1.5*(Vd300_vds_135(j+20*(i-1))-Vd300_vds_135(j+20*(i-1)+10));
        Vd450_VDT_135(j+10*(i-1))=1.5*(Vd450_vds_135(j+20*(i-1))-Vd450_vds_135(j+20*(i-1)+10));
        Vd150_VDT_246(j+10*(i-1))=1.5*(Vd150_vds_246(j+20*(i-1))-Vd150_vds_246(j+20*(i-1)+10));
        Vd300_VDT_246(j+10*(i-1))=1.5*(Vd300_vds_246(j+20*(i-1))-Vd300_vds_246(j+20*(i-1)+10));
        Vd450_VDT_246(j+10*(i-1))=1.5*(Vd450_vds_246(j+20*(i-1))-Vd450_vds_246(j+20*(i-1)+10));
    end
end

%拟合每组数据的a与b两个参数
coe_a=[];
coe_b=[];
coe_Vdc=[];
coe_Td=[];
coe_fs=[];
Vdc=[150 300 450];
Td=[1 2 3 4 5 6];
Td=Td*1e-6;
fs=[10000 5000 15000];
ids_fit_pre=([ 0.05 0.06 0.07 0.08 0.09 0.1 0.15 0.2 0.5 1]*IN)';
ids_fit_pre=Current_fix(ids_fit_pre);
for i=1:9
    VDT_fit_now=Vd150_VDT_135(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd150_values_ab_135(1,i)=coe(1);
    Vd150_values_ab_135(2,i)=coe(2);

    VDT_fit_now=Vd300_VDT_135(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd300_values_ab_135(1,i)=coe(1);
    Vd300_values_ab_135(2,i)=coe(2);

    VDT_fit_now=Vd450_VDT_135(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd450_values_ab_135(1,i)=coe(1);
    Vd450_values_ab_135(2,i)=coe(2);

    VDT_fit_now=Vd150_VDT_246(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd150_values_ab_246(1,i)=coe(1);
    Vd150_values_ab_246(2,i)=coe(2);

    VDT_fit_now=Vd300_VDT_246(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd300_values_ab_246(1,i)=coe(1);
    Vd300_values_ab_246(2,i)=coe(2);

    VDT_fit_now=Vd450_VDT_246(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd450_values_ab_246(1,i)=coe(1);
    Vd450_values_ab_246(2,i)=coe(2);
end

%排序并且加上Vdc Td fs
Vdc=[150 300 450];
Td1=[1 3 5]*1e-6;
Td2=[2 4 6]*1e-6;
fs=[10000 5000 15000];
for i=1:3
    for j=1:3
        Vd150_values_ab_135(4,j+3*(i-1))=Vd150_values_ab_135(1,j+3*(i-1));
        Vd150_values_ab_135(5,j+3*(i-1))=Vd150_values_ab_135(2,j+3*(i-1));
        Vd150_values_ab_135(1,j+3*(i-1))=150;
        Vd150_values_ab_135(2,j+3*(i-1))=Td1(i);
        Vd150_values_ab_135(3,j+3*(i-1))=fs(j);

        Vd300_values_ab_135(4,j+3*(i-1))=Vd300_values_ab_135(1,j+3*(i-1));
        Vd300_values_ab_135(5,j+3*(i-1))=Vd300_values_ab_135(2,j+3*(i-1));
        Vd300_values_ab_135(1,j+3*(i-1))=300;
        Vd300_values_ab_135(2,j+3*(i-1))=Td1(i);
        Vd300_values_ab_135(3,j+3*(i-1))=fs(j);


        Vd450_values_ab_135(4,j+3*(i-1))=Vd450_values_ab_135(1,j+3*(i-1));
        Vd450_values_ab_135(5,j+3*(i-1))=Vd450_values_ab_135(2,j+3*(i-1));
        Vd450_values_ab_135(1,j+3*(i-1))=450;
        Vd450_values_ab_135(2,j+3*(i-1))=Td1(i);
        Vd450_values_ab_135(3,j+3*(i-1))=fs(j);

        Vd150_values_ab_246(4,j+3*(i-1))=Vd150_values_ab_246(1,j+3*(i-1));
        Vd150_values_ab_246(5,j+3*(i-1))=Vd150_values_ab_246(2,j+3*(i-1));
        Vd150_values_ab_246(1,j+3*(i-1))=150;
        Vd150_values_ab_246(2,j+3*(i-1))=Td2(i);
        Vd150_values_ab_246(3,j+3*(i-1))=fs(j);

        Vd300_values_ab_246(4,j+3*(i-1))=Vd300_values_ab_246(1,j+3*(i-1));
        Vd300_values_ab_246(5,j+3*(i-1))=Vd300_values_ab_246(2,j+3*(i-1));
        Vd300_values_ab_246(1,j+3*(i-1))=300;
        Vd300_values_ab_246(2,j+3*(i-1))=Td2(i);
        Vd300_values_ab_246(3,j+3*(i-1))=fs(j);


        Vd450_values_ab_246(4,j+3*(i-1))=Vd450_values_ab_246(1,j+3*(i-1));
        Vd450_values_ab_246(5,j+3*(i-1))=Vd450_values_ab_246(2,j+3*(i-1));
        Vd450_values_ab_246(1,j+3*(i-1))=450;
        Vd450_values_ab_246(2,j+3*(i-1))=Td2(i);
        Vd450_values_ab_246(3,j+3*(i-1))=fs(j);
    end
end

write_temp2=[Vd150_values_ab_135 Vd150_values_ab_246 Vd300_values_ab_135 Vd300_values_ab_246 Vd450_values_ab_135 Vd450_values_ab_246]';

xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\Sim_Data.xlsx',write_temp2,'sheet2','A1');

%%
% %找出仿真中对应实验数据的数据
write_temp3=[];
for i=1:size(write_temp2,1)
    for j=1:size(write_temp1,1)
        if write_temp2(i,1)==write_temp1(j,1) && write_temp2(i,2)==write_temp1(j,2) && write_temp2(i,3)==write_temp1(j,3)
            write_temp3(i,1:5)=write_temp2(i,1:5);
            write_temp3(i,6:7)=write_temp1(j,4:5);
        end
    end
end
%实验数据在前，仿真数据在后
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\Sim_Data.xlsx',write_temp3,'sheet3','A1');

%%
%画图
plot_x=0:IN/200:IN;
for i=1:size(write_temp3,1)
    ploty1=write_temp3(i,4)*2/pi*atan(write_temp3(i,5)*plot_x);
    ploty2=write_temp3(i,6)*2/pi*atan(write_temp3(i,7)*plot_x);
    plot(plot_x,ploty1,'r',plot_x,ploty2,'b');
    label=strcat('Vdc=',num2str(write_temp3(i,1)),' fs=',num2str(write_temp3(i,3)),' Td=',num2str(write_temp3(i,2)),'num=',num2str(i));
    xlabel(label);
    ylabel('补偿电压(V)');
    title('仿真与实验补偿电压对比');
    %             legend('实验补偿值');
    %             hold on;
    %             plot(plot_x,ploty2,'b');
    %             xlabel(['Vdc=' vd_str(i) ' fs=' fs_str(j) ' Td=' Td_str(m)]);
    %             ylabel('补偿电压(V)');
    %             title('仿真与实验补偿电压对比');
    legend('实验补偿值','仿真补偿值');
    test=1;

end