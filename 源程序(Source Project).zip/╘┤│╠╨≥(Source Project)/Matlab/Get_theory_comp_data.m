function [a,b]=Get_theory_comp_data(Ts,Td,Vdc,Rs,C,Ton,Toff,Ld,IN)
%%
%计算死区暂态范围，根据
%死区的暂态区域在2023.11.20
%计算电流上下限,在该电流区域内，死区线性增加
i_tranmax=Vdc*(Ts+2*Td)/(Ts*Rs+4*Ld);
% i_tranmin=Vdc*(Ts-4*Td)/(2*Ts*Rs+8*Ld);
i_tranmin=0;

%%
%计算补偿值并且拟合
ia=0:IN/100:IN;
deltaV=zeros(size(ia,2),1);
for i=1:size(ia,2)
    if ia(i)>=i_tranmax
        Td_use=Td;
    elseif ia(i)<=i_tranmin
        Td_use=0;
    else
        Td_use=(ia(i)-i_tranmin)*Td/(i_tranmax-i_tranmin);
    end
    VSW=VswVDfit(ia(i),1);
    VD=VswVDfit(ia(i),2);
    deltaV(i)=Cal_deltaV_final1(Ts,Td_use,Vdc,VSW,VD,Rs,ia(i),C,Ton,Toff);
end
%%
%拟合
% plot(ia,deltaV);
% a=0;
% b=0;
VDT_fit_now=deltaV;
[fitresult, gof] = createFit(ia, VDT_fit_now);
coe=coeffvalues(fitresult);
a=coe(1);
b=coe(2);




