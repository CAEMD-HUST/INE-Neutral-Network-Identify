function [fitresult, gof] = createFit(ids_fit, VDT_fit_now)
%CREATEFIT(IDS_FIT,VDT_FIT_NOW)
%  创建一个拟合。
%
%  要进行 '无标题拟合 1' 拟合的数据:
%      X 输入: ids_fit
%      Y 输出: VDT_fit_now
%  输出:
%      fitresult: 表示拟合的拟合对象。
%      gof: 带有拟合优度信息的结构体。
%
%  另请参阅 FIT, CFIT, SFIT.

%  由 MATLAB 于 16-Dec-2023 17:43:50 自动生成


%% 拟合: '无标题拟合 1'。
[xData, yData] = prepareCurveData( ids_fit, VDT_fit_now );

% 设置 fittype 和选项。
ft = fittype( 'a*2/pi*atan(b*(x+c))', 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.StartPoint = [0.933993247757551 0.678735154857773 0.757740130578333];

% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );

% % 绘制数据拟合图。
% figure( 'Name', '无标题拟合 1' );
% h = plot( fitresult, xData, yData );
% legend( h, 'VDT_fit_now vs. ids_fit', '无标题拟合 1', 'Location', 'NorthEast', 'Interpreter', 'none' );
% % 为坐标区加标签
% xlabel( 'ids_fit', 'Interpreter', 'none' );
% ylabel( 'VDT_fit_now', 'Interpreter', 'none' );
% grid on


