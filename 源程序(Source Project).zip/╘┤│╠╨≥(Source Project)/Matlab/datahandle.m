%%
%读入数据并预处理得到死区补偿数据 fs=10000 5000 15000，DT=1us 3us 5us
clear all;
clc;
IN=10.6;
%%
global coe_A;
global coe_B;
%%
% 处理135us
adjust_coe=0;
Vd150_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=150.dat");
Vd300_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=300.dat");
Vd450_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT135 fs5 15 10\Vd=450.dat");
Vd150_VDT=zeros(90,1);
Vd300_VDT=zeros(90,1);
Vd450_VDT=zeros(90,1);

for i=1:9
    for j=1:10
        Vd150_VDT(j+10*(i-1))=1.5*(Vd150_vds(j+20*(i-1))-Vd150_vds(j+20*(i-1)+10));
        Vd300_VDT(j+10*(i-1))=1.5*(Vd300_vds(j+20*(i-1))-Vd300_vds(j+20*(i-1)+10));
        Vd450_VDT(j+10*(i-1))=1.5*(Vd450_vds(j+20*(i-1))-Vd450_vds(j+20*(i-1)+10));
    end
end

%拟合每组数据的a与b两个参数
Vd150_values_ab=zeros(2,9);
Vd300_values_ab=zeros(2,9);
Vd450_values_ab=zeros(2,9);
ids_fit_pre=([0 0.05 0.06 0.07 0.08 0.09 0.1 0.15 0.2 0.5 1]*IN)';
ids_fit_pre=Current_fix(ids_fit_pre);
for i=1:9
    VDT_fit_now=Vd150_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd150_values_ab(1,i)=coe(1);
    Vd150_values_ab(2,i)=coe(2);

    VDT_fit_now=Vd300_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd300_values_ab(1,i)=coe(1);
    Vd300_values_ab(2,i)=coe(2);

    VDT_fit_now=Vd450_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd450_values_ab(1,i)=coe(1);
    Vd450_values_ab(2,i)=coe(2);
end

%原始数据与拟合数据写入excel
Vd150_values_ab_write=[Vd150_values_ab(1:2,1:3);Vd150_values_ab(1:2,4:6);Vd150_values_ab(1:2,7:9)];
Vd300_values_ab_write=[Vd300_values_ab(1:2,1:3);Vd300_values_ab(1:2,4:6);Vd300_values_ab(1:2,7:9)];
Vd450_values_ab_write=[Vd450_values_ab(1:2,1:3);Vd450_values_ab(1:2,4:6);Vd450_values_ab(1:2,7:9)];
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd150_values_ab_write,'sheet2','B3');
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd300_values_ab_write,'sheet2','G3');
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd450_values_ab_write,'sheet2','L3');
%理论值写入
ADD(1,1)="C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx";
ADD(1,2)=ADD(1,1);
ADD(1,3)=ADD(1,1);
ADD(2,1)="sheet2";
ADD(2,2)="sheet2";
ADD(2,3)="sheet2";
ADD(3,1)="B12";
ADD(3,2)="G12";
ADD(3,3)="L12";
draw_theory_ab(10000,5000,15000,1,3,5,150,300,450,ADD);
%%
%处理246

Vd150_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=150.dat");
Vd300_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=300.dat");
Vd450_vds=importdata("C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\DT246 fs5 15 10\Vd=450.dat");
Vd150_VDT=zeros(90,1);
Vd300_VDT=zeros(90,1);
Vd450_VDT=zeros(90,1);

for i=1:9
    for j=1:10
        Vd150_VDT(j+10*(i-1))=1.5*(Vd150_vds(j+20*(i-1))-Vd150_vds(j+20*(i-1)+10));
        Vd300_VDT(j+10*(i-1))=1.5*(Vd300_vds(j+20*(i-1))-Vd300_vds(j+20*(i-1)+10));
        Vd450_VDT(j+10*(i-1))=1.5*(Vd450_vds(j+20*(i-1))-Vd450_vds(j+20*(i-1)+10));
    end
end

%拟合每组数据的a与b两个参数
Vd150_values_ab=zeros(2,9);
Vd300_values_ab=zeros(2,9);
Vd450_values_ab=zeros(2,9);
ids_fit_pre=([0 0.05 0.06 0.07 0.08 0.09 0.1 0.15 0.2 0.5 1]*IN)';
ids_fit_pre=Current_fix(ids_fit_pre);
for i=1:9
    VDT_fit_now=Vd150_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd150_values_ab(1,i)=coe(1);
    Vd150_values_ab(2,i)=coe(2);

    VDT_fit_now=Vd300_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd300_values_ab(1,i)=coe(1);
    Vd300_values_ab(2,i)=coe(2);

    VDT_fit_now=Vd450_VDT(1+(i-1)*10:9+(i-1)*10,1);
    VDT_fit_now=[0;VDT_fit_now;(VDT_fit_now(size(VDT_fit_now,1),1)-VDT_fit_now(size(VDT_fit_now,1)-1,1))*adjust_coe+VDT_fit_now(size(VDT_fit_now,1),1)];
    [fitresult, gof] = createFit(ids_fit_pre, VDT_fit_now);
    coe=coeffvalues(fitresult);
    Vd450_values_ab(1,i)=coe(1);
    Vd450_values_ab(2,i)=coe(2);
end

%原始数据与拟合数据写入excel
Vd150_values_ab_write=[Vd150_values_ab(1:2,1:3);Vd150_values_ab(1:2,4:6);Vd150_values_ab(1:2,7:9)];
Vd300_values_ab_write=[Vd300_values_ab(1:2,1:3);Vd300_values_ab(1:2,4:6);Vd300_values_ab(1:2,7:9)];
Vd450_values_ab_write=[Vd450_values_ab(1:2,1:3);Vd450_values_ab(1:2,4:6);Vd450_values_ab(1:2,7:9)];
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd150_values_ab_write,'sheet2','Q3');
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd300_values_ab_write,'sheet2','V3');
xlswrite('C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx',Vd450_values_ab_write,'sheet2','AA3');
%理论值写入
ADD(1,1)="C:\Users\Fame\Desktop\EX PROJECT\论文\死区补偿与迁移学习\DATA AND MATH MODEL\EXPERIMENT\raw_and_fitted_data.xlsx";
ADD(1,2)=ADD(1,1);
ADD(1,3)=ADD(1,1);
ADD(2,1)="sheet2";
ADD(2,2)="sheet2";
ADD(2,3)="sheet2";
ADD(3,1)="Q12";
ADD(3,2)="V12";
ADD(3,3)="AA12";
draw_theory_ab(10000,5000,15000,2,4,6,150,300,450,ADD);