id1=table2array(rawandfitteddataS2(:,1));
VDT1=table2array(rawandfitteddataS2(:,2));
id2=table2array(rawandfitteddataS2(:,3));
VDT2=table2array(rawandfitteddataS2(:,4));



[xData, yData] = prepareCurveData( id1, VDT1 );

% 设置 fittype 和选项。
ft = fittype( 'a*pi/2*atan(b*(x+c))', 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.StartPoint = [0.933993247757551 0.678735154857773 0.757740130578333];

% 对数据进行模型拟合。
[fitresult1, gof1] = fit( xData, yData, ft, opts );

[xData, yData] = prepareCurveData( id2, VDT2 );
[fitresult2, gof2] = fit( xData, yData, ft, opts );