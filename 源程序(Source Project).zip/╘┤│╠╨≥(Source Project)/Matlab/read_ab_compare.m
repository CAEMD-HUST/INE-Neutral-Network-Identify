%%
%该函数用于读出各个死区以及开关频率下仿真与实验得出的补偿值，并且画图比较
clear all;
clc;
IN=10.6;
vd_str=["150V" "300V" "450V"];
Td_str=["1us" "2us" "3us" "4us" "5us" "6us"];
fs_str=["10000Hz" "5000Hz" "15000Hz" ];
readx1=["B" "G" "L" "Q" "V" "AA"];
readx2=["D" "I" "N" "S" "X" "AC"];
ready1=["3" "4" "5" "6" "7" "8" ];
ready2=["3" "4" "5" "6" "7" "8" ];
%%
%实验数据
data_exp=[];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','B3:D8')];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','G3:I8')];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','L3:N8')];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','Q3:S8')];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','V3:X8')];
data_exp=[data_exp,xlsread('raw_and_fitted_data.xlsx','sheet2','AA3:AC8')];
data_a_exp=[];
data_b_exp=[];
data_x=[0 9 0 9 0 9];
data_y=[1 1 3 3 5 5];
for i=1:3%Vdc
    for j=1:3%fs
        for m=1:6%Td
            data_a_exp=[data_a_exp,data_exp(data_y(m),data_x(m)+(i-1)*3+j)];
            data_b_exp=[data_b_exp,data_exp(data_y(m)+1,data_x(m)+(i-1)*3+j)];
        end
    end
end
%sim
data_sim=[];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','B12:D17')];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','G12:I17')];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','L12:N17')];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','Q12:S17')];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','V12:X17')];
data_sim=[data_sim,xlsread('raw_and_fitted_data.xlsx','sheet2','AA12:AC17')];
data_a_sim=[];
data_b_sim=[];
data_x=[0 9 0 9 0 9];
data_y=[1 1 3 3 5 5];
for i=1:3%Vdc
    for j=1:3%fs
        for m=1:6%Td
            data_a_sim=[data_a_sim,data_sim(data_y(m),data_x(m)+(i-1)*3+j)];
            data_b_sim=[data_b_sim,data_sim(data_y(m)+1,data_x(m)+(i-1)*3+j)];
        end
    end
end
%%
%画图
plot_x=0:IN/200:IN;
for i=1:3%Vdc
    for j=1:3%fs
        for m=1:6%Td
            x_size=(i-1)*18+(j-1)*6+m;
            ploty1=data_a_exp(x_size)*2/pi*atan(data_b_exp(x_size)*plot_x);
            ploty2=data_a_sim(x_size)*2/pi*atan(data_b_sim(x_size)*plot_x);
            plot(plot_x,ploty1,'r',plot_x,ploty2,'b');
            label=strcat('Vdc=',vd_str(i),' fs=',fs_str(j),' Td=',Td_str(m));
            xlabel(label);
            ylabel('补偿电压(V)');
            title('仿真与实验补偿电压对比');
%             legend('实验补偿值');
%             hold on;
%             plot(plot_x,ploty2,'b');
%             xlabel(['Vdc=' vd_str(i) ' fs=' fs_str(j) ' Td=' Td_str(m)]);
%             ylabel('补偿电压(V)');
%             title('仿真与实验补偿电压对比');
            legend('仿真补偿值','实验补偿值');
            test=1;
        end
    end
end

